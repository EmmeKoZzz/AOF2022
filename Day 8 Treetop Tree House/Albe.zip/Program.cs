﻿using System.Diagnostics;

namespace Day_8_albe;

static class App
{
    public static void Main()
    {
        string[] input = new StreamReader("../../../input.txt").ReadToEnd()
            .Split("\n", StringSplitOptions.RemoveEmptyEntries);

        Stopwatch time = new();
        time.Start();

        var matrix = new int[input.Length, input[0].Length];
        int[,] matrix_copy = FullMatrix(input);

        seek_amount_trees(matrix, matrix_copy);

        time.Stop();

        Console.WriteLine(time.Elapsed.Nanoseconds);
    }

    static void seek_amount_trees(int[,] matrix, int[,] matrix_copy)
    {
        int count = 0;
        count += counter_matrix(matrix, matrix_copy);
        MatrixT(matrix);
        MatrixT(matrix_copy);
        count += counter_matrix(matrix, matrix_copy);

        Console.WriteLine(count);
    }

    static int counter_matrix(int[,] matrix, int[,] matrix_copy)
    {
        int count = 0;
        for (int i = 0; i < matrix.GetLength(0); i++)
            count += counter(matrix, matrix_copy, i);

        return count;
    }

    static int counter(int[,] matrix, int[,] matrix_copy, int line)
    {
        int matrixLength = matrix.GetLength(0);
        int count = 0;
        
        if (line == 0 || line == matrixLength)
            for (int i = 0; i < matrixLength; i++)
            {
                if (matrix[line, i] != 1)
                    count++;
                matrix[line, i] = 1;
            }
        else
        {
            count += matrix[line, 0] != 1 ? 1 : 0;
            matrix[line, 0] = 1;

            count += matrix[line, matrixLength - 1] != 1 ? 1 : 0;
            matrix[line, matrixLength - 1] = 1;

            int[] row = GetChunkArray(matrix_copy, 0, matrixLength, line);

            for (int i = 1; i < matrixLength - 1; i++)
            {
                int[] firstHalf = new int[i];
                Array.Copy(
                    row, 0,
                    firstHalf, 0,
                    i
                );
                
                int[] secondHalf = new int[matrixLength - i - 1];
                Array.Copy(
                    row, i + 1,
                    secondHalf, 0,
                    matrixLength - i - 1
                );

                bool first = firstHalf.Max() < matrix_copy[line, i];
                bool second = secondHalf.Max() < matrix_copy[line, i];

                if (first || second)
                {
                    count += matrix[line, i] != 1 ? 1 : 0;
                    matrix[line, i] = 1;
                }
            }
        }

        return count;
    }

    static int[,] FillMatrix(string[] input)
    {
        int n = input.Length, m = input[0].Length;
        int[,] matrix = new int[n, m];

        for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++)
            matrix[i, j] = int.Parse("" + input[i][j]);

        return matrix;
    }

    static void MatrixT(int[,] matrix)
    {
        for (int i = 0; i < matrix.GetLength(0); i++)
        for (int j = i; j < matrix.GetLength(0); j++)
            (matrix[j, i], matrix[i, j]) = (matrix[i, j], matrix[j, i]);
    }

    static T[] GetChunkArray<T>(T[,] arr, int start, int end, int line)
    {
        T[] chunk = new T[end - start];

        for (int i = start, j = 0; i < end; i++, j++)
            chunk[j] = arr[line, i];

        return chunk;
    }
}